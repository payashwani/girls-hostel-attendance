const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

require('dotenv').config();

const profileRoutes = require('./routes/profileroute');
const complaintRoutes = require('./routes/complaintroute');
const attendanceRoutes = require('./routes/attendanceroute');
const feesRoutes = require('./routes/feesroute');
const foodMenuRoutes = require('./routes/foodmenuroute');
const authRoutes = require('./routes/authRoutes'); // ✅ Add authentication routes


const app = express();
const port = 5000; // Declare the port to be used for the backend server

// Middleware to parse incoming JSON data
app.use(express.json());
// Enable CORS for the frontend to connect
app.use(cors());

// ✅ Authentication Routes
app.use('/api/auth',authRoutes); 

app.use('/api/Profile', profileRoutes);
app.use('/api/Complaint', complaintRoutes);
app.use('/api/Attendance', attendanceRoutes);
app.use('/api/Fees', feesRoutes);
app.use('/api/FoodMenu', foodMenuRoutes);

// MongoDB connection string (from .env)
const MONGO_URI = process.env.MONGO_URI;

// Connect to MongoDB
mongoose.connect(MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('MongoDB connected');
}).catch((err) => {
    console.log('MongoDB connection error:', err);
});

// Sample route for testing
app.get('/api', (req, res) => {
  res.json({ message: 'Hello from the backend!' });
});

// Start the server on the specified port
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
