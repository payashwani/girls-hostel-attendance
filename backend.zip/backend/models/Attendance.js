const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    date: { type: Date, default: Date.now },
    image: { type: String, required: true }, // Store uploaded image URL
    status: { type: String, enum: ['Present', 'Absent'], default: 'Present' }
});

const Attendance = mongoose.model('Attendance', attendanceSchema);
module.exports = Attendance;
