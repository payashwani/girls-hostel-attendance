const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    phone: { type: String, required: true, unique: true, match: /^[0-9]{10}$/ }, // 10-digit phone validation
    profileImage: { type: String }, // Store image URL or filename
    password: { type: String, required: true }, // ✅ Add Password
    role: { type: String, enum: ["student", "warden"], default: "student" }
}, { timestamps: true });

const User = mongoose.models.User || mongoose.model("User", userSchema); // ✅ Prevent Overwrite Error

module.exports = User;



