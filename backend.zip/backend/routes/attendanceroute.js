// routes/attendanceRoutes.js
const express = require('express');
const Attendance = require('../models/attendance'); // Attendance model
const router = express.Router();

// Route to mark attendance
router.post('/', async (req, res) => {
  const { date, studentId, imageUrl } = req.body;
  try {
    const newAttendance = new Attendance({ date, studentId, imageUrl });
    await newAttendance.save();
    res.status(201).json(newAttendance);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Route to get all attendance records
router.get('/', async (req, res) => {
  try {
    const attendanceRecords = await Attendance.find();
    res.json(attendanceRecords);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Export the router
module.exports = router;
