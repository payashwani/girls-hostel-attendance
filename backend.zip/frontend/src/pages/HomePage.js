import React from 'react';

function HomePage() {
  return <h2>Welcome to the Home Page</h2>;
}

export default HomePage;
