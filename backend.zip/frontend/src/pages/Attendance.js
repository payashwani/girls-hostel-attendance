import React, { useState } from "react";
import axios from "axios";

const Attendance = () => {
  const [image, setImage] = useState(null);
  const [studentId, setStudentId] = useState("");

  const handleImageChange = (e) => {
    setImage(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("studentId", studentId);
    formData.append("image", image);

    try {
      await axios.post("http://localhost:5000/api/Attendance", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      alert("Attendance marked successfully!");
    } catch (error) {
      console.error(error);
      alert("Error marking attendance!");
    }
  };

  return (
    <div>
      <h2>Mark Attendance</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Student ID"
          value={studentId}
          onChange={(e) => setStudentId(e.target.value)}
        />
        <input type="file" onChange={handleImageChange} />
        <button type="submit">Submit Attendance</button>
      </form>
    </div>
  );
};

export default Attendance;
