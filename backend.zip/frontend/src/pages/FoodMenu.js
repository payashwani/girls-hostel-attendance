import React, { useState, useEffect } from "react";
import axios from "axios";

const FoodMenu = () => {
  const [menu, setMenu] = useState([]);

  useEffect(() => {
    const fetchMenu = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/FoodMenu/1");
        setMenu(response.data.menuItems);
      } catch (error) {
        console.error(error);
      }
    };

    fetchMenu();
  }, []);

  return (
    <div>
      <h2>Food Menu for the Week</h2>
      <ul>
        {menu.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    </div>
  );
};

export default FoodMenu;
