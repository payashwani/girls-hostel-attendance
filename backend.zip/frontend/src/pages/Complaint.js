import React, { useState } from "react";
import axios from "axios";

const Complaint = () => {
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const complaintData = { message };

    try {
      await axios.post("http://localhost:5000/api/Complaint", complaintData);
      alert("Complaint submitted successfully!");
    } catch (error) {
      console.error(error);
      alert("Error submitting complaint!");
    }
  };

  return (
    <div>
      <h2>Submit Complaint</h2>
      <form onSubmit={handleSubmit}>
        <textarea
          placeholder="Enter your complaint"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <button type="submit">Submit Complaint</button>
      </form>
    </div>
  );
};

export default Complaint;
