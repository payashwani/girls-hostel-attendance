import React, { useState } from "react";
import axios from "axios";


const Profile = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [roomNumber, setRoomNumber] = useState("");


  const handleSubmit = async (e) => {
    e.preventDefault();
    const profileData = { name, email, phone, roomNumber };


    try {
      await axios.post("http://localhost:5000/api/Profile", profileData);
      alert("Profile created successfully!");
    } catch (error) {
      console.error(error);
      alert("Error creating profile!");
    }
  };


  return (
    <div>
      <h2>Create Profile</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="text"
          placeholder="Phone"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
        />
        <input
          type="text"
          placeholder="Room Number"
          value={roomNumber}
          onChange={(e) => setRoomNumber(e.target.value)}
        />
        <button type="submit">Create Profile</button>
      </form>
    </div>
  );
};


export default Profile;

