import React, { useState } from "react";
import axios from "axios";

const Fees = () => {
  const [screenshot, setScreenshot] = useState(null);
  const [studentId, setStudentId] = useState("");

  const handleScreenshotChange = (e) => {
    setScreenshot(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("studentId", studentId);
    formData.append("screenshot", screenshot);

    try {
      await axios.post("http://localhost:5000/api/Fees", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      alert("Fee uploaded successfully!");
    } catch (error) {
      console.error(error);
      alert("Error uploading fee!");
    }
  };

  return (
    <div>
      <h2>Upload Fee Payment Screenshot</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Student ID"
          value={studentId}
          onChange={(e) => setStudentId(e.target.value)}
        />
        <input type="file" onChange={handleScreenshotChange} />
        <button type="submit">Submit Fee</button>
      </form>
    </div>
  );
};

export default Fees;
