import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import HomePage from './pages/HomePage';
import Profile from './pages/Profile';
import Attendance from './pages/Attendance';
import Complaint from './pages/Complaint';
import Fees from './pages/Fees';
import FoodMenu from './pages/FoodMenu';

function App() {
  return (
    <Router>
      <div className="App">
        <h1>Welcome to the Girls' Hostel Website</h1>
        
        {/* Define Routes */}
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/attendance" element={<Attendance />} />
          <Route path="/complaint" element={<Complaint />} />
          <Route path="/fees" element={<Fees />} />
          <Route path="/food-menu" element={<FoodMenu />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
